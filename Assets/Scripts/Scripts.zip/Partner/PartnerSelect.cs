using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PartnerSelect : MonoBehaviour
{
    public GameObject partner;

    void Start()
    {
        GameObject.Find("Character0").transform.position = new Vector3(0, 0, 0);
        GameObject.Find("Character1").transform.position = new Vector3(-6.43f, 0, 0);
    }
}
