using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class test : MonoBehaviour
{

    public void print()
    {
        Debug.Log("���");

    }

}
