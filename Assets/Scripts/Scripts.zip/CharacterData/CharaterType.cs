using System.Collections;
using System.Collections.Generic;
using UnityEngine;

    public enum CharacterType
    {
        Warrior = 0, Mage, Cleric, Thief, Popstar, Chef
    }

   // int count = System.Enum.GetValues(typeof(CharacterType)).Length;
