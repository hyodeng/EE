﻿using System.Collections;
using UnityEngine;

public class Monster : CharacterData
{

}